const { callTest, getSample } = require("../../lib/mars");
const {
  MIN_WEIGHT_A,
  MIN_WEIGHT_B,
  MIN_WEIGHT_C,
} = require("../../lib/constants");

function splitSample() {
  /* Write your solution here */
}

function applyTestA() {
  /* Write your solution here */
}

function applyTestB() {
  /* Write your solution here */
}

function applyTestC() {
  /* Write your solution here */
}

function applyTestD() {
  /* Write your solution here */
}

function performExperiment() {
  /* Write your solution here */
  /* You need to use the above functions here */
}

module.exports = {
  applyTestA,
  applyTestB,
  applyTestC,
  applyTestD,
  performExperiment,
  splitSample,
};
