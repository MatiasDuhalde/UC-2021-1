const IGNORE = ['í', ' ', ',', '.', ';'];

function getFrequencies(text) {
  const frequencies = {};
  let validChars = 0;
  for (let i = 0; i < text.length; i++) {
    if (!IGNORE.includes(text[i])) {
      if (frequencies[text[i]]) {
        frequencies[text[i]].count++;
      } else {
        frequencies[text[i]] = { count: 1 };
      }
      validChars++;
    }
  }
  Object.keys(frequencies).forEach(key => {
    frequencies[key].frequency = (frequencies[key].count / validChars) * 100;
  });
  return frequencies;
}

function getClosest(character, freqTable, realFreq) {
  charFreq = realFreq[character].frequency;
  let currentMin = freqTable[0];
  let minIndex = 0;
  freqTable.forEach((entry, index) => {
    if (Math.abs(entry.f - charFreq) <= Math.abs(currentMin.f - charFreq)) {
      currentMin = entry;
      minIndex = index;
    }
  });
  freqTable.splice(minIndex, 1);
  return currentMin;
}

function decryptText(text, freq) {
  const realFrequencies = getFrequencies(text);
  let replaceObj = {};
  Object.keys(realFrequencies).forEach(key => {
    const closest = getClosest(key, freq, realFrequencies);
    replaceObj[key] = closest.l;
  });
  let decoded = '';
  for (let i = 0; i < text.length; i++) {
    const toReplace = replaceObj[text[i]];
    decoded += toReplace || text[i];
  }
  return decoded;
}

module.exports = {
  decryptText,
};
