# Selección de preguntas

- Frontend (HTML/CSS): Pregunta C
- Programación 1: Pregunta D
- Programación 2: Pregunta G
