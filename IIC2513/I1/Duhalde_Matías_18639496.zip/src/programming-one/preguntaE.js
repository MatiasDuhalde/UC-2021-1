/*
  You have access to MIN_STOCK here
  Change the value if you want to test different scenarios.
*/
const { MIN_STOCK } = require("../../lib/constants");

function retrieveElements(arrayMisc, arrayIndexes) {
  /* Write your solution here */
}

function checkStock(store) {
  /* Write your solution here */
}

function itemsByBranch(store, branch) {
  /* Write your solution here */
}

module.exports = {
  checkStock,
  itemsByBranch,
  retrieveElements,
};
