function checkDNA(originalString, finalString) {
  const mutations = [];
  for (let i = 0; i < originalString.length; i++) {
    if (originalString[i] !== finalString[i]) {
      const mutation = {
        pos: i,
        original: originalString[i],
        mutation: finalString[i],
      };
      mutations.push(mutation);
    }
  }
  return mutations;
}

module.exports = {
  checkDNA,
};
