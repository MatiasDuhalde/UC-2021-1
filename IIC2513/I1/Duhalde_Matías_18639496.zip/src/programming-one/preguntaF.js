function isFriendly(arrayNumbers) {
  /* Write your solution here */
}

module.exports = {
  isFriendly,
};
